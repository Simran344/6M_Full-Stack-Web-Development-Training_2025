import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
/*import Product from "./Components/Product";
import Location from "./Components/Location";
import Country from './Components/Country';*/
import List from "./Components/List";
import Form from "./Components/Form"
import {BrowserRouter,Route,Routes} from 'react-router-dom'
import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle.min.js"
import Logout from './Components/Logout';
import Main from "./Components/task/Main"
import Register from './Components/Register';
import Parent from './Components/Pages/Context/Parent';
import Pdf from './Components/Pdf';
import { PDFDownloadLink } from '@react-pdf/renderer';

function App() {
 
  return (
    <>
    
      {/*<BrowserRouter>
      <Routes>
        <Route path="/" element={<Main/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/parent" element={<Parent/>}/>
        <Route path="/pdf" element={<Pdf/>}/>
      </Routes>
      </BrowserRouter>*/}
      <h1>Generate PDF from Array of Objects</h1>
    <PDFDownloadLink document={<Pdf />} fileName="user_information.pdf">
      {({ loading }) => (loading ? 'Loading document...' : 'Download PDF')}
    </PDFDownloadLink>
    

    </>
  )
}

export default App
