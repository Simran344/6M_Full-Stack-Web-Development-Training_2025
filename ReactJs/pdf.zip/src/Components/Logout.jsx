import Modal from "react-modal"
import { useNavigate } from "react-router-dom";
import { useState } from "react";
export default function Logout(){
    const[isOpen,setIsOpen]=useState(false)
    const nav=useNavigate()
    const customStyles = {
        content: {
          top: '50%',
          left: '50%',
          right: 'auto',
          bottom: 'auto',
          marginRight: '-50%',
          transform: 'translate(-50%, -50%)',
        },
      };
    return(
        <>
         <button style={{backgroundColor:"blue",color:"white"}} onClick={()=>{setIsOpen(true)}}>Log out</button>
         <Modal isOpen={isOpen} style={customStyles}>
            <h2>Logout Confirmation</h2>
            <p>Are you sure you want to logout?</p>
            <button style={{backgroundColor:"blue",color:"white"}} onClick={()=>{setIsOpen(false)}}>Confirm</button>
            <button style={{border:"1px blue solid",marginLeft:"10px"}} onClick={()=>nav("/")}>Cancel</button>
         </Modal>
        </>
    )
}