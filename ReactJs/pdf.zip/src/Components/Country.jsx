export default function Country({name})
{
    return(
        <p>{name}</p>
        
    )
}