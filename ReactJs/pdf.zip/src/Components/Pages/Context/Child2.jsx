import { UserContext } from "./Parent";
import Child3 from "./Child3";
import { createContext, useContext } from "react";
export let StudentContext=createContext();
export default function Child2(){
   let stu={name:"jasmeen",course:"airlines",duration:"3 years"}
   let cont=useContext(UserContext)
   return(
    <>
    <StudentContext.Provider value={stu}>
    <h1>Hello i am child2</h1>
    <h1>Name is:{cont.name}</h1>
    <p>Course is:{cont.course}</p>
    <p>Duration:{cont.duration}</p>
    <Child3/>
    </StudentContext.Provider>
    </>
   )
}