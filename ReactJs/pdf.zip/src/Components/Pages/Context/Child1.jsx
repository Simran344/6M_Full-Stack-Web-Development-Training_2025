import { UserContext } from "./Parent";
import Child2 from "./Child2";
import { useContext } from "react";
export default function Child1(){
   let cont=useContext(UserContext)
   return(
    <>
    <h1>Hello i am child1</h1>
    <h1>Name is:{cont.name}</h1>
    <p>Course is:{cont.course}</p>
    <p>Duration:{cont.duration}</p>
    <Child2/>
    </>
   )
}