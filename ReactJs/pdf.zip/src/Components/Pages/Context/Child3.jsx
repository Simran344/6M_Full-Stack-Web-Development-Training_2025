import { useContext } from "react";
import { StudentContext } from "./Child2";
import { UserContext } from "./Parent";
export default function Child3(){
    let cont=useContext(StudentContext)
    let cont1=useContext(UserContext)
    return(
        <>
        <h1>Hello i am child3</h1>
        <h1>Name is:{cont.name}</h1>
        <p>Course:{cont.course}</p>
        <p>Duration:{cont.duration}</p>
        <p>Name is{cont1.name}</p>
        <p>Course is:{cont1.course}</p>
        </>
    )
}