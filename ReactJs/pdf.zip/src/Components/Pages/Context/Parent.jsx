import Child1 from "./Child1"
import { createContext } from "react"

export let UserContext=createContext()
export default function Parent(){
    let user={name:"Simran",course:"MERN Stack",duration:"6 months"}
    return(
        <>
        <UserContext.Provider value={user}>
            <h1>Hello this is parent</h1>
            <Child1/>
        </UserContext.Provider>
        </>
    )
}