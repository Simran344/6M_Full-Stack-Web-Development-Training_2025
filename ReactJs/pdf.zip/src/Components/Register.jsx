import { useForm } from "react-hook-form";
import { data } from "react-router-dom";

export default function Register(){
    const{register,handleSubmit,formState:{errors},watch}=useForm();
    const handleForm=(data)=>{
        console.log(data)
    }
    const handleError=(errors)=>{
        console.log(errors);
    }
    return(
        <>
        <div className="container">
                <div className="row">
                    <div className="col-4 mx-auto my-5">
                        <h2 className="text-center">Login Form</h2>

                        <form onSubmit={handleSubmit(handleForm,handleError)}>
              <div className="row g-3">
                <div className="col-12">
                  <div className="form-floating">
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      placeholder="Your email"
                      {...register("email",{required:{value:"true",message:"name is requires"},pattern:{
                        value:/^[A-Za-z0-9\-\_\.]+\@+[a-zA-Z0-9]+\.+[a-zA-z]{2,3}$/,
                        message:"pattern is not valid"
                      }})}
                     
                    />
                    <label htmlFor="email">Your Email</label>
                  </div>
                  <span className="text-danger">{errors?.email?.pattern?.message}</span>
                  <span className="text-danger">{errors?.email?.message}</span>
                </div>
              
                
                <div className="col-12">
                  <div className="form-floating">
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      placeholder="Your Password"
                     {...register("password",{required:{value:"true",message:"password is required"},pattern:{
                        value:/^[A-Za-z0-9\-\_\@]+$/,message:"pattern of password is not valid"
                     },minLength:{
                        value:8,message:"length of password is less than 8"
                     }})}
                    />
                    <label htmlFor="password">Your Password</label>
                  </div>
                  <span className="text-danger">{errors?.password?.message}</span>
                </div>
                <div className="col-12">
                  <div className="form-floating">
                    <input
                      type="tel"
                      className="form-control"
                      id="telephone"
                      placeholder="Your mobile number"
                     {...register("number",{required:{value:"true",message:"number is required"},minLength:{
                        value:10,message:"number is less than 10 digit"},maxLength:{
                            value:10,message:"number is more than 10 digit"}
                        
                     })}
                    />
                    <label htmlFor="telephone">your mobile number</label>
                  </div>
                  <span className="text-danger">{errors?.number?.message}</span>
                </div>
                <label>Gender</label>
               
                    <input
                      type="radio"
                      
                      id="rad1"
                      name="gender"
                      value="male"
                     {...register("gender")}
                    />
                    <label htmlFor="rad1">Male</label>
              
               
                    <input
                      type="radio"
                    
                      id="rad2"
                      name="gender"
                      value="female"
                     {...register("gender")}
                    />
                    <label htmlFor="rad2">Female</label>
                    <label>Select State:</label>
        <select name="sel" 
         {...register("State",{required:{value:"true",message:"State is mandatory to fill"}})} defaultValue="">
           
            <option value="" disabled>Select State</option> 
            <option value="Maharashtar">Maharashtar</option>
            <option value="Karnataka">Karnataka</option>
            <option value="Gujarat">Gujarat</option>
            <option value="Indore">Indore</option>
            <option value="Punjab">Punjab</option>
            <option value="Uttar Pradesh">Uttar Pradesh</option>
           
        </select><br/><br/>
        <span className="text-danger">{errors?.State?.message}</span>        
                <input type="checkbox" value="terms and conditions" {...register("terms and conditions")}/>
                <label>Terms and conditions accepted</label>
                
                <div className="col-6 mx-auto">
                  <button className="btn btn-primary w-100 py-3" type="submit">
                    Login
                  </button>
                </div>
              </div>
            </form>

                   
                </div>
           </div>
          
           </div>
           <p>{watch("email")}</p>
           <p>{watch("gender")}</p>
           <p>{watch("State")}</p>
           <p>{watch("password")}</p>
           <p>{watch("terms and conditions")}</p>
        </>
    )
}