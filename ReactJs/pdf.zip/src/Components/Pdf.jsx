import React from 'react';
import { Page, Text, View, Document, StyleSheet, PDFDownloadLink } from '@react-pdf/renderer';
import data from './Data';
// Sample array of objects


// Create styles
const styles = StyleSheet.create({
  page: {
    padding: 30,
  },
  section: {
    marginBottom: 10,
  },
  header: {
    fontSize: 18,
    marginBottom: 10,
  },
  text: {
    fontSize: 12,
  },
});

// Create Document Component
export default function Pdf() {
    return(
  <Document>
    <Page style={styles.page}>
      <Text style={styles.header}>Restaurant Information</Text>
      {data.map((user,index) => {
        return(
        <View key={index} style={styles.section}>
          <Text style={styles.text}>Name: {user.info.name}</Text>
          <Text style={styles.text}>Ratings: {user.info.rating.rating_text}</Text>
         
        </View>
      )})}
    </Page>
  </Document>
)
}

