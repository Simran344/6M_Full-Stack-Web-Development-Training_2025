export default function Props(props){
    const syntax=` return(
        <>
        <p>title:{props.title}</p>
        <p>Description:{props.desc}</p>
        <p>Syntax:{syntax}</p>
        </>
    )`
    return(
        <>
        <p>title:{props.title}</p>
        <p>Description:{props.desc}</p>
        <p>Syntax:{syntax}</p>
        </>
    )
}