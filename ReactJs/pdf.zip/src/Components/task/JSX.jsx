import {Link} from "react-router-dom"
export default function Introduction(props){
    const syntax=` return(
        <>
        <p>name:{props.title}</p>
        <p>description:{props.desc}</p>
        <p>Syntax:{syntax}</p>
      
        </>
    )`
    
    return(
        <>
        <p>name:{props.title}</p>
        <p>description:{props.desc}</p>
        <p>Syntax:{syntax}</p>
      
        </>
    )
}