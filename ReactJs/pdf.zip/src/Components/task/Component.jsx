export default function Component(props){
    const syntax=`return(
            <>
            <p>title:{props.title}</p>
            <p>title:{props.desc}</p>
            <p>syntax:{syntax}</p>
            </>
    )`
    return(
        <>
        <p>title:{props.title}</p>
        <p>description:{props.desc}</p>
        <p>syntax:{syntax}</p>
        </>
    )
}