export default function Cart(props){
    console.log(props)
    return(
    <div style={{marginLeft:"300px"}}>
    <table border="2px" style={{borderCollapse:"collapse"}}>
        <thead>
            <tr>
                <td>Item Name</td>
                <td>Price</td>
                <td>Quantiy</td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{props.name}</td>
                <td>{props.price}</td>
                <td>{props.Quantity}</td>
            </tr>
        </tbody>
    </table>
    </div>
    )
}