export default function Contact(props){
    return(
        <table border="2px" style={{borderCollapse:"collapse",borderColor:"white",backgroundColor:"blue",color:"white"}}>
            <thead>
                <tr>
                    <td>Person Name</td>
                    <td>Phone Number</td>
                    <td>Email id</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{props.pName}</td>
                    <td>{props.number}</td>
                    <td>{props.email}</td>

                </tr>
            </tbody>
        </table>
    )
}