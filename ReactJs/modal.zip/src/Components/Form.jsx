import { useState } from "react";
export default function Form(){
    const state=useState();
    const[edit,setNa]=useState();
    const[email,setEm]=useState();
    const[passwd,setPd]=useState();
    const[gender,setRd]=useState();
    const[states,setSt]=useState();
    const[check,seter]=useState();
    function setName(e){
        setNa(e.target.value)
    }
    function setEmail(e){
        setEm(e.target.value)
    }
    function setPass(e){
        setPd(e.target.value)
    }
    function setRadio(e){
        setRd(e.target.value)
    }
    function setState(e){
        setSt(e.target.value )
    }
    function setTerms(e){
        seter(e.target.checked)
    }
    return(
        <>
         <h1 className="text-center">Login Form</h1>
        <label>Name:</label>
        <input type="text" onChange={setName}  placeholder="Enter your name" value={edit}/><br/>
        <label>Email:</label>
        <input type="text" onChange={setEmail}  placeholder="enter your email" value={email}/><br/>
        
        <label>Password:</label>
        <input type="password" onChange={setPass} placeholder="enter your password" value={passwd}/><br/>
        <label>Gender</label><br/>
        <input type="radio" value="male" onChange={setRadio} name="option"/>
        <label>Male</label><br/>
        <input type="radio" value="female" onChange={setRadio} name="option"/>
        <label>Female</label><br/>
        <label>Select State:</label>
        <select onChange={setState}>
            <option>Maharashtar</option>
            <option>Karnataka</option>
            <option>Gujarat</option>
            <option>Indore</option>
            <option>Punjab</option>
            <option>Uttar Pradesh</option>
        </select><br/><br/>
        <input type="checkbox" onChange={setTerms}/>
        <label>Terms and Conditions Accepted</label><br/>
        <p>name:{edit}</p>
        <p>email:{email}</p>
        
        <p>state:{states}</p>
        <p>gender:{gender}</p>

        <p>password:{passwd}</p>
        <p>Terms and Conditions:{check?"accepted":"not accepted"}</p>
        </>
    )
}