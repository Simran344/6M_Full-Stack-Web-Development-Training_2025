import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
/*import Product from "./Components/Product";
import Location from "./Components/Location";
import Country from './Components/Country';*/
import List from "./Components/List";
import Form from "./Components/Form"
import {BrowserRouter,Route,Routes} from 'react-router-dom'
import Logout from './Components/Logout';

function App() {
 
  return (
    <>
     
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Form/>}/>
        <Route path="/list" element={<List/>}/>
        <Route path="/Logout" element={<Logout/>}/>
      </Routes>
      </BrowserRouter>
    

    </>
  )
}

export default App
