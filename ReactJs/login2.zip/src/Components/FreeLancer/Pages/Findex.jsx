
export default function Findex(){
    return(
        <>
        <h1>Freelancer!!!</h1>
        </>
    )
} 