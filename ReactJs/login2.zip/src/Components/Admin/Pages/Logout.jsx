import { useState } from "react";
import PageTitle from "../Layouts/PageTitle";
import Modal from "react-modal";

export default function Logout(){
    

    return(
        <>
        <PageTitle>Log out</PageTitle>
        

        </>
    )
}