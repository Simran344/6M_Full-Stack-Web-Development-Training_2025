export default function Cindex(){
    return(
        <>
        <h1>Clients!!!</h1>
        </>
    )
} 