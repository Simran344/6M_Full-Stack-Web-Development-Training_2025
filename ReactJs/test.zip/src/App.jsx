import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Product from "./Components/Product";
import Location from "./Components/Location";
import Country from './Components/Country';

function App() {
  let arr=[
    {name:"Smart Watch",price:"50,000",description:"its a brilliant smart watch"},
    {name:"Shirt",price:"1,000",description:"its a cotton shirt"},
    {name:"Necklace",price:"70,000",description:"its 24k gold necklace"}
  ]

  return (
    <>
      <Product{...arr}/>
      <Location/>
      <Country name="America"/>
      <Country name="Cananda"/>

    </>
  )
}

export default App
