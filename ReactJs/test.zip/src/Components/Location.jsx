import { Fragment } from "react"

export default function Location(){
    let loc=["Amrtsar","patnankot","Jalandhar","ludhiana","Kartarpur"]
    console.log(loc)
    return(
        <>
        {loc.map((locs,index)=>{
            return(
            
                <Fragment key={index}>
                <span>{locs}</span><br/>
                </Fragment>
            
            )

        })}
        </>
    )
}