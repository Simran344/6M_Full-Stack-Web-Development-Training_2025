export default function Weather({cityName,temperature,humidity,weatherCond}){
    return(
        <table border="2px" style={{borderCollapse:"collapse",borderColor:"white",backgroundColor:"brown",color:"white"}}>
            <thead>
                <tr>
                    <td>City</td>
                    <td>Temperature</td>
                    <td>Humidity</td>
                    <td>Weather Condition</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{cityName}</td>
                    <td>{temperature}</td>
                    <td>{humidity}</td>
                    <td>{weatherCond}</td>
                </tr>
            </tbody>
        </table>
    )
}