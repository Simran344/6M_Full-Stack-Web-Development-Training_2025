import "./Product.css";
export default function Product({name,price,Description}){
    return(
    <div className="main">
        <table className="class1" border={"2px"} >
            <thead>
                <tr>
                    <td>Product Name</td>
                    <td>Price</td>
                    <td>Description</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{name}</td>
                    <td>{price}</td>
                    <td>{Description}</td>
                </tr>
            </tbody>
        </table>
    </div>
    )
}