import "./Employee.css"
export default function Employee() {
    return (
        <div className="myEmployee" style={{justifyContent:"center"}}>
          
        <table border="2" className="myClass">
            <thead>
                <tr>
                    <td>Employee Name</td>
                    <td>Age</td>
                    <td>Department</td>
                    <td>Salary</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Alice</td>
                    <td>30</td>
                    <td>IT</td>
                    <td>60,000</td>
                </tr>
                <tr>
                    <td>Joy</td>
                    <td>35</td>
                    <td>Marketing</td>
                    <td>50,000</td>
                </tr>
                <tr>
                    <td>Jane Smith</td>
                    <td>40</td>
                    <td>HR</td>
                    <td>90,000</td>
                </tr>
                <tr>
                    <td>Bob Johnson</td>
                    <td>50</td>
                    <td>Finance</td>
                    <td>40,000</td>
                </tr>
            </tbody>
        </table>
        </div>
    )
}