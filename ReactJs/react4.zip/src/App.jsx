import Employee from "./Components/Employee";
import Student from "./Components/Student";
import Cart from "./Components/Cart";
import Product from "./Components/Product";
import Contact from "./Components/Contact";
import Weather from "./Components/Weather";
import Div from "./Components/Div";
import StudentArray from "./Components/StudentArray";
import Employeearr from "./Components/Employeearr";
import Zomato from "./Components/Zomato";


function App() {
  
  let id1 = 101;
  let name1 = "Simran";
  let age1 = 22;

  let id2 = 102;
  let name2 = "Jasmeen";
  let age2 = 18;

  return (
    
     <div>
      <Employee/><br/>
      <Employee/><br/>
      <Employee/><br/>
      <Student studentId={id1} studentName={name1} studentAge={age1} /><br/>
      <Student studentId={id2} studentName={name2} studentAge={age2}/>
      <Cart name="Apple" price={40} Quantity={5}/><br/>
      <Cart name="Banana" price={30} Quantity={6}/><br/>
      <Product name="Gold Necklace" price={1299.99} Description="Elegant 24K gold necklace"/><br/>
      <Product name="Silver Ring" price={199.99} Description="925 Sterling Silver Ring"/><br/>
      <Product name="Smart Watch" price={299.99} Description="Latest smartwatch with fitness tracking"/><br/>
      <Contact pName="Simran" number={9815384556} email="simran@gmail.com"/><br/>
      <Contact pName="Jasmeen" number={6239533468} email="jas@gmail.com"/><br/>
      <Contact pName="Purva" number={6235546890} email="purva@gmail.com"/><br/>
      <Contact pName="Babita" number={9855678912} email="babita@gmail.com"/><br/>
      <Weather cityName="Jalandhar" temperature="64°F" humidity="26%" weatherCond="Mostly Cloudy"/><br/>
      <Weather cityName="New Delhi" temperature="63°F" humidity="46%" weatherCond="Clear"/><br/>
      <Weather cityName="Mumbai" temperature="82°F" humidity="41%" weatherCond="Sunny"/><br/>
      <Div/>

      <StudentArray/>
      <Employeearr/>
      <Zomato/>
     </div>
  )
}

export default App
