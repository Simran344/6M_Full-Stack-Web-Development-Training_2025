import Employee from "./Components/Employee";
import Student from "./Components/Student";
import Cart from "./Components/Cart";
import Product from "./Components/Product";
import Contact from "./Components/Contact";
import Weather from "./Components/Weather";
import Div from "./Components/Div";
import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle.min.js"
import StudentArray from "./Components/StudentArray";
import Employeearr from "./Components/Employeearr";
import Zomato from "./Components/zomato/Zomato";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Path from "./Components/Path";


function App() {

  let id1 = 101;
  let name1 = "Simran";
  let age1 = 22;

  let id2 = 102;
  let name2 = "Jasmeen";
  let age2 = 18;

  return (

    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Path />} />
          <Route path="/div" element={<Div />} />
          <Route path="/contact" element={<Contact pName="Simran" number={9815384556} email="simran@gmail.com" />} />
          <Route path="/employee" element={<Employee />} />
          <Route path="/student" element={<Student studentId={id1} studentName={name1} studentAge={age1} />} />
          <Route path="/cart" element={<Cart name="Apple" price={40} Quantity={5} />} />
          <Route path="/product" element={<Product name="Gold Necklace" price={1299.99} Description="Elegant 24K gold necklace" />} />
          <Route path="/weather" element={<Weather cityName="Jalandhar" temperature="64°F" humidity="26%" weatherCond="Mostly Cloudy" />} />
          <Route path="/studentarray" element={<StudentArray />} />
          <Route path="/employeearr" element={<Employeearr />} />
          <Route path="/zomato" element={<Zomato />} />

        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
