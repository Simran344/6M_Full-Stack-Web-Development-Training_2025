import { Fragment } from "react"

export default function Employeearr(){
    let employee=[
        {name:"Alice",dept:"IT",salary:"60,000"},
        {name:"Joy",dept:"Marketing",salary:"50,000"},
        {name:"Jane Smith",dept:"HR",salary:"90,000"},
        {name:"Bob",dept:"Teacher",salary:"40,000"}
    ]
    return(
        <div style={{backgroundColor:"aqua",boxShadow:"10px 10px 5px blue",margin:"110px"}}>
            <h1><u>Employee Data</u></h1>
        {employee.map((employees,index)=>{
            return(
                <Fragment key={index}>
                    <span><strong>Name:</strong><em>{employees.name}</em>     </span>
                    <span><strong>Department:</strong><em>{employees.dept}</em>     </span>
                    <span><strong>Salary:</strong><em>{employees.salary}</em></span>
                    <br/>
                </Fragment>
            )
        })}
        </div>
    )
}