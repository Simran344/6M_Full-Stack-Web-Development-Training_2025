import { Link } from "react-router-dom"
export default function Path() {
    return (
        <>

            <Link to={"/contact"}>1.Contact</Link><br />
            <Link to={"/div"}>2.Div</Link><br />
            <Link to={"/employee"}>3.Employee</Link><br />
            <Link to={"/student"}>4.Student</Link><br />
            <Link to={"/cart"}>5.Cart</Link><br />
            <Link to={"/product"}>6.Product</Link><br />
            <Link to={"/weather"}>7.Weather</Link><br />
            <Link to={"/studentarray"}>8.StudentArray</Link><br />
            <Link to={"/employeearr"}>9.Employeearr</Link><br />
            <Link to={"/zomato"}>10.Zomato</Link>


        </>
    )
}