import data from "./ZomatoData";
export default function Zomato(){
    let total=0;
    return(
        <>
        {data.map((ele,index)=>(
           
            total+=parseFloat(ele.info.rating.rating_text)
            
       )
    )}
       
       <table className="table table-bordered table-hover">
            <thead>
                <tr> 
                    <td>SNo</td>
                    <td>Name</td>
                    <td>Image</td>
                    <td>Rating</td>
                </tr>
            </thead>
            <tbody>
        
        {data.map((ele,index)=>{
            return( 
                   <>
                   
                   <tr key={index}>
                        
                       <td>{index+1}</td>
                       <td>{ele.info.name}</td>
                       <td><img src={ele.info.image.url} style={{height:"100px", width:"100px"}}/></td>
                       <td className={ele?.info?.rating?.rating_text>=4?"text-success":ele.info.rating.rating_text>=3?"text-danger":"text-info"}>{ele.info.rating.rating_text}</td>
                   </tr> 
                </>
            )

        })}
        </tbody>
    </table>
       
    </>
    
    )
}