export default function Weather({cityName,temperature,humidity,weatherCond}){
    return(
        <table className="table table-bordered table-success" >
            <thead>
                <tr>
                    <td>City</td>
                    <td>Temperature</td>
                    <td>Humidity</td>
                    <td>Weather Condition</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{cityName}</td>
                    <td>{temperature}</td>
                    <td>{humidity}</td>
                    <td>{weatherCond}</td>
                </tr>
            </tbody>
        </table>
    )
}