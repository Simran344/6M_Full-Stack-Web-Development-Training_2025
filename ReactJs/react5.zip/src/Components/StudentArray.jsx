import { Fragment } from "react"

export default function StudentArray(){
    let arr=["simran","jasmeen","aliya","purva","babita"]
    return(
        <>
        {arr.map((ele,index)=> {
            return(
            <Fragment key={index}>
            <p>{ele}</p>
            </Fragment>
            )
        })}
        </>
       
    )
}