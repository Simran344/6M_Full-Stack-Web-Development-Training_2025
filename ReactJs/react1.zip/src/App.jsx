import Employee from "./Components/Employee";
import Student from "./Components/Student";

function App() {
  
  let id1 = 101;
  let name1 = "Simran";
  let age1 = 22;

  let id2 = 102;
  let name2 = "Jasmeen";
  let age2 = 18;

  return (
    
     <div>
      <Employee/><br/>
      <Employee/><br/>
      <Employee/><br/>
      <Student studentId={id1} studentName={name1} studentAge={age1} /><br/>
      <Student studentId={id2} studentName={name2} studentAge={age2}/>
     </div>
  )
}

export default App
