export default function Student({studentId,studentName,studentAge}){
            return(
                <table border="2" style={{borderCollapse:"collapse"}}>
                    <thead>
                    <tr>
                        <td>Student ID</td>
                        <td>Name</td>
                        <td>Age</td>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>{studentId}</td>
                        <td>{studentName}</td>
                        <td>{studentAge}</td>
                    </tr>
                    </tbody>
                </table>
            )
}