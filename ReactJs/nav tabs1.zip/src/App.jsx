import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
/*import Product from "./Components/Product";
import Location from "./Components/Location";
import Country from './Components/Country';*/
import List from "./Components/List";
import Form from "./Components/Form"
import {BrowserRouter,Route,Routes} from 'react-router-dom'
import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle.min.js"
import Logout from './Components/Logout';
import Main from "./Components/task/Main"

function App() {
 
  return (
    <>
    
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Main/>}/>
        
      </Routes>
      </BrowserRouter>
    

    </>
  )
}

export default App
