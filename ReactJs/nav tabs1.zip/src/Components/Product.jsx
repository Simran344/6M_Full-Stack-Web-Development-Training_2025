import { Fragment } from "react";

export default function Product({items}){
    
   
  
    
       
    
   
    return(
    
        <table border="2px">
            <thead>
                <tr>
                    <td>Name:</td>
                    <td>Price:</td>
                    <td>Description:</td>
                </tr>
            </thead>
            <tbody>
        
                   {items.map((arrs,index)=>{
            
                   
                    return(
                        <Fragment key={index}>
                       <tr>
                       <td>{arrs.name}</td>
                       <td>{arrs.price}</td>
                       <td>{arrs.description}</td>
                       </tr>
                   
                    </Fragment>
                    )
                    
                   
             
            

        })}
        </tbody>
       </table>
    )
}