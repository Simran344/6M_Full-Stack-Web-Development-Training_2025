import  JSX  from "./JSX"
import Component from "./Component"
import Props from "./Props"
import ReactJs from "./ReactJs"
import State from "./State"

import {useState} from 'react'
export default function Main(){
    const state=useState()
    const[sta,setState]=useState("")
    let arr=[{name:"Component",compo:Component,title:"About Components in React",desc:"In React, components are reusable, independent pieces of UI that manage their own state and behavior. They can be functional components (stateless/stateful functions) or class components (ES6 classes extending React.Component). Components help in building dynamic and modular applications."},

      {name:"JSX",compo:JSX,title:"About JSX",desc:"JSX is a syntax extension for JavaScript that allows writing HTML-like code inside React. It makes UI creation easier by combining markup and logic in the same file. JSX must be transpiled into regular JavaScript using Babel."},

      {name:"Props",compo:Props,title:"About Props",desc:"Props (short for 'properties') are used to pass data from a parent component to a child component in React. They are read-only and help make components reusable by allowing dynamic content."},

      {name:"ReactJs",compo:ReactJs,title:"About ReactJs",desc:"React.js is a JavaScript library for building fast and interactive user interfaces using a component-based architecture. It efficiently updates the UI with a virtual DOM and supports state management, making it ideal for single-page applications (SPAs)"},

      {name:"State",compo:State,title:"About State",desc:"State in React is an object that stores dynamic data and controls a component's behavior. It allows components to re-render when data changes, making them interactive and responsive. State is managed using the useState hook in functional components."}
    ]
   
     
    return(
        <>
       <ul className="nav nav-tabs">
  <li className="nav-item">
    <button className={`nav-link ${sta=="Component" && "active"}`} onClick={()=>{setState("Component")}} >Components</button>
    
  </li>
  <li className="nav-item">
    <button className={`nav-link  ${sta=="JSX" && " active"}`} onClick={()=>{setState("JSX")}}>JSX</button>
  </li>
  <li className="nav-item">
    <button className={`nav-link ${sta=="Props" && "active"}`} onClick={()=>{setState("Props")}}>Props</button>
  </li>
  <li className="nav-item">
    <button className={`nav-link ${sta=="ReactJs" && "active"}`} onClick={()=>{setState("ReactJs")}} >ReactJs</button>
  </li>
  <li className="nav-item">
    <button className={`nav-link ${sta=="State"&& "active"}`} onClick={()=>{setState("State")}}>State</button>
  </li>
</ul>
{sta=="" && <p>Select an option</p>}
 {arr.map((ele,index)=>{
  return(
    <div key={index}>
 {sta==ele.name && <ele.compo {...ele}/> }

 </div> 
  )
 })}

        </>
    )
}