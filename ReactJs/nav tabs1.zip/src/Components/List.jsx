import { useState } from "react";
export default function List(){
    const state=useState();
    const[add,setAdd]=useState("")
    const[edit,setEd]=useState([]);
    function setAd(e){
       setAdd(e.target.value)
    }
    
     function setDit(){
       
       
        setEd([...edit,add])
        setAdd("")
        
        
     }
     return(
        <>
        <input type="text" placeholder="Add a new to-do" value={add} onChange={setAd} style={{height:"30px"}}/>
        <button onClick={setDit} style={{backgroundColor:"aqua",color:"white",border:"1px solid black",marginLeft:"7px"}}>Add</button>
        
        <table border="2px">
            <thead>
                <tr>
                    <td>S.no</td>
                    <td>Item</td>
                </tr>
            </thead>
            <tbody>
                {edit.map((ele,index)=>
                {   return(
                    
                    <tr key={index}>
                        <td>{index+1}</td>
                        <td>{ele}</td>
                    </tr>
                )
                })}
            </tbody>
        </table><br/>
        
        </>
     )
}