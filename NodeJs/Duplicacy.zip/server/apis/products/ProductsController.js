const ProductsModel=require("./ProductsModel")
add=(req,res)=>{
    ProductsModel.findOne({category:req.body.category})
    .then(async(productData)=>{
        if(!productData){
            let productsObj=new ProductsModel
            let total=await ProductsModel.countDocuments().exec()
            productsObj.autoId=total+1
            productsObj.category=req.body.category
            productsObj.name=req.body.name
            productsObj.brand=req.body.brand
            productsObj.price=req.body.price
            productsObj.quantity=req.body.quantity
            productsObj.description=req.body.description
            productsObj.image=req.body.image
            productsObj.stock=req.body.stock
            productsObj.save()
            .then((productData)=>{
            res.json({
                status:200,
                success:true,
                message:"Category Added",
                data:productData
            })
        })
            .catch((err)=>{
                res.json({
                    status:500,
                    success:false,
                    message:"Internal server error",
                    error:err
                })
            }) 
        }
        else{
            res.json({
                status:200,
                success:true,
                message:"Category already exist with same name",
                data:productData
            })
        }
    })
   
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })

}
get=async (req,res)=>{
    try{
        const result=await ProductsModel.find()
        res.json({
            status:200,
            success:true,
            message:"data fetched!!",
            data:result
        })
    }
    catch{
        res.json({
            status:500,
            success:false,
            message:"Internal server error"
        })
    }
}
module.exports={add,get}