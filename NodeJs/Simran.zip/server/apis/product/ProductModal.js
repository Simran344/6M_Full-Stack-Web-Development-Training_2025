const mongoose=require("mongoose")

let ProductSchema=mongoose.Schema({
    id:{type:String,default:""},
    name:{type:String,default:""},
    description:{type:String,default:""},
    status:{type:Boolean,default:true},
    createdAt:{type:Date,default:Date.now()}
})

module.exports=mongoose.model("ProductModal",ProductSchema)