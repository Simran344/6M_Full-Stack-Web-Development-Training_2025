const ProductModal=require("./ProductModal")
add=(req,res)=>{
    let ProductObj=new ProductModal
       ProductObj.id=req.query.id
       ProductObj.name=req.query.name
       ProductObj.description=req.query.description
       ProductObj.save()
       .then((result)=>{
           res.json({
               status:200,
               success:true,
               message:"Add api of product is working",
               data:result
           })
       })
       .catch((err)=>{
           res.json({
               status:500,
               success:false,
               message:"Internal server error",
               error:err
           })
       })
}

view=async (req,res)=>{
    const result=await ProductModal.find()

    try{
        res.json({
            status:200,
            success:true,
            message:"data fetched",
            data:result

        })
    }
    catch{
        res.json({
            status:500,
            success:false,
            message:"internal server error"
        })
    }
}
module.exports={add,view}