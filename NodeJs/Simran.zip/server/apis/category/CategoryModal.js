const mongoose=require("mongoose")

let CategorySchema=mongoose.Schema({
    id:{type:String,default:""},
    name:{type:String,default:""},
    description:{type:String,default:""},
    status:{type:Boolean,default:true},
    createdAt:{type:Date,default:Date.now()}
})
module.exports=mongoose.model("CategoryModal",CategorySchema);