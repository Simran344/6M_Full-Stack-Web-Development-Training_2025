const CategoryModal=require("./CategoryModal")

add=(req,res)=>{
    let CategoryObj=new CategoryModal
    CategoryObj.id=req.query.id
    CategoryObj.name=req.query.name
    CategoryObj.description=req.query.description
    CategoryObj.save()
    .then((result)=>{
        res.json({
            status:200,
            success:true,
            message:"Add api of category is working",
            data:result
        })
    })
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })
}
view=async (req,res)=>{
    const result=await CategoryModal.find()

    try{
        res.json({
            status:200,
            success:true,
            message:"data fetched",
            data:result

        })
    }
    catch{
        res.json({
            status:500,
            success:false,
            message:"internal server error"
        })
    }
}
module.exports={add,view}