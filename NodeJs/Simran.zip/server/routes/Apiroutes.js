
const CategoryController=require("../apis/category/CategoryController")
const ProductController=require("../apis/product/ProductController")

const router=require("express").Router()

router.get("/category/add",CategoryController.add)
router.get("/product/add",ProductController.add)
router.get("/category/view",CategoryController.view)
router.get("/product/view",ProductController.view)
module.exports=router