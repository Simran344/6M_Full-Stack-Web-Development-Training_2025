const express=require("express")

const PORT=5000;

const app=express()
app.listen(PORT,()=>{
    console.log("port is listening")
})
const api=require("./server/routes/Apiroutes")

app.use("/api",api)