const CategoryController=require("../apis/category/CategoryController")
const ProductsController=require("../apis/products/ProductsController")
const router=require("express").Router()

router.get("/category/add",CategoryController.add)
router.get("/category/create",CategoryController.create)
router.get("/category/delete",CategoryController.Delete)
router.get("/category/update",CategoryController.update)
router.get("/category/read",CategoryController.read)


router.get("/products/add",ProductsController.add)
router.get("/products/create",ProductsController.create)
router.get("/products/delete",ProductsController.Delete)
router.get("/products/update",ProductsController.update)
router.get("/products/read",ProductsController.read)


module.exports=router