add=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Add product Api is working"
    })
}
create=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Create product Api is working"
    })
}
Delete=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Delete product Api is working"
    })
}
update=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Update product Api is working"
    })
}
read=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Read product Api is working"
    })
}
module.exports={add,create,Delete,update,read}