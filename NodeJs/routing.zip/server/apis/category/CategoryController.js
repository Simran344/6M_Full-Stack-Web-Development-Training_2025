add=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Add category api is working"
    })
}

create=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Create category api is working"
    })
}
Delete=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Delete category Api is working"
    })
}
update=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Update category Api is working"
    })
}
read=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"read category Api is working"
    })
}
module.exports={add,create,Delete,update,read}