const express=require("express")

const PORT=5000;

const api=express()
api.use(express.urlencoded({extended:true}))
api.use(express.json({limit:"40mb"}))

api.listen(PORT,()=>{
    console.log("PORT is connected")
})
const app=require("./server/routes/Apiroutes");
const db=require("./server/config/db")

api.use("/Vote",app)