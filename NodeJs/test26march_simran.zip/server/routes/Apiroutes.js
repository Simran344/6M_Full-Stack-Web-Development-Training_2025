const PollController=require("../api/Poll/PollController");
const VotingController=require("../api/Voting/VotingController");

const route=require("express").Router()
route.get("/Poll/add",PollController.add)
route.get("/Voting/add",VotingController.add)

module.exports=route