const PollModal=require("./PollModal")

add=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData.answer){
        validation+="answer is required"
    }
    if(!formData.option1){
        validation+="option1 is required"
    }
    if(!formData.option2){
        validation+="option2 is required"
    }
    if(!formData.option3){
        validation+="option3 is required"
    }
    if(!formData.option4){
        validation+="option4 is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:true,
            message:"please gave answer"
        })
    }
    else{
    let PollObj=new PollModal()
    PollObj.question=formData.question;
    PollObj.option1=formData.option1;
    PollObj.option2=formData.option2;
    PollObj.option3=formData.option3;
    PollObj.option4=formData.option4;
    PollObj.answer=formData.answer;
    let total=PollModal.countDocuments().exec()
    PollObj.autoId=total+1
    PollObj.save()
    .then((result)=>{
        res.json({
            status:200,
            success:true,
            data:result
        })
    })
    .catch((err)=>{
        res.json({
            status:404,
            success:false,
            message:"Internal server error"
        })
    })
} 

}
module.exports={add}