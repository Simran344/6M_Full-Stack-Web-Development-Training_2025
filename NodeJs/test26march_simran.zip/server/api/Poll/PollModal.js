const mongoose=require("mongoose")

let PollSchema=mongoose.Schema({
    autoId:{type:Number,default:1},
    option1:{type:String,default:""},
    option2:{type:String,default:""},
    option3:{type:String,default:""},
    option4:{type:String,default:""},
    answer:{type:String,default:""}
})

module.exports=mongoose.model("PollModal",PollSchema)