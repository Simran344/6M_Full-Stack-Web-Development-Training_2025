const VotingModal=require("./VotingModal")

add=(req,res)=>{
    let validation="";
    let formData=req.body;
    if(!formData.user_email){
        validation+="email is required"
    }
    if(!formData.questionId){
        validation+="question id is required"
    }
    if(!formData.answer){
        validation+="answer is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:true,
            message:"validation error"
        })
    }
    else{
        VotingModal.findOne({user_email:formData.user_email})
        .then((result)=>{
            if(!result){
                let VotingObj=new VotingModal()
                VotingObj.user_email=formData.user_email;
                VotingObj.questionId=formData.questionId;
                VotingObj.answer=formData.answer;
                VotingObj.save()
                .then((VotingData)=>{
                    res.json({
                        status:200,
                        success:true,
                        data:VotingData
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:404,
                        success:false,
                        error:err,
                        message:"data not added"
                    })
                })
            }
            else{
                res.json({
                    status:200,
                    success:true,
                    message:"data is already added"


                })
            }
        })
        .catch((err)=>{
            res.json({
                status:404,
                success:false,
                message:"Internal server error"
            })
        })
    }
}
module.exports={add}