const express=require("express")

const app=express()

const PORT=5001;
app.use(express.urlencoded({extended:true}))
app.use(express.json({limit:"40mb"}))
app.use(express.static("./server/public/"))
app.listen(PORT,()=>{
    console.log("port is listening",PORT)
})
const db=require("./server/config/db")
const api=require("./server/routes/ApiRoutes")

app.use("/api",api)

app.get("/",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Server is running"
    })
})


app.all("/**",(req,res)=>{
  res.status(404).json({
      status:404,
      success:true,
      message:"Not found!!"
  })
})
var weather = require('weather-js');
 
// Options:
// search:     location name or zipcode
// degreeType: F or C
 console.log(weather)
app.get("/weather",(req,res)=>{
    let y=req.query.name
    let degree=req.query.degree
    console.log(req.query)
weather.find({search: y, degreeType:degree}, function(err, result) {
   
  if(err) console.log(err);
  if(result.length==0){
    console.log("no result found")
  }
  
  else{
    console.log(JSON.stringify(result,null,2))
  }
  
  res.json({
    status:200,
    success:true,
    location:result[0].location.name,
    temperature:result[0].current.temperature
  })
})




})
app.get("/weathers/:loc/:degree",(req,res)=>{
    console.log(req.params)
   let loc=req.params.loc;
   let degree=req.params.degree
   console.log(req.params)
weather.find({search:loc, degreeType:degree}, function(err, result) {
   
  if(err) console.log(err);
  if(result.length==0){
    console.log("no result found")
  }
  
  else{
    console.log(JSON.stringify(result,null,2))
  }
  
  res.json({
    status:200,
    success:true,
    location:result[0].location.name,
    temperature:result[0].current.temperature
  })
})
})