const ProductsModel=require("./ProductsModel")
add=(req,res)=>{
    console.log(req.file)
    let validation=""
    let formData=req.body
    if(!formData.category){
        validation+="Category is required"
        console.log(validation)
    }
    if(!formData.name){
        validation+="product name is required"
        console.log(validation)
    }
    if(!formData.brand){
        validation+="brand name is required"
        console.log(validation)
    }
    if(!formData.price){
        validation+="price is required"
        console.log(validation)
    }
    if(!formData.quantity){
        validation+="quantity is required"
        console.log(validation)
    }
    if(!formData.description){
        validation+="description is required"
        console.log(validation)
    }
    if(!formData.stock){
        validation+="stock  is required"
        console.log(validation)
    }
    if(!req.file){
        validation+="img is required to upload"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:"validation error"
        })
    }
    else{
    ProductsModel.findOne({category:formData.category})
    .then(async(productData)=>{
        if(!productData){
            let productsObj=new ProductsModel
            let total=await ProductsModel.countDocuments().exec()
            productsObj.autoId=total+1
            productsObj.category=formData.category
            productsObj.name=formData.name
            productsObj.brand=formData.brand
            productsObj.price=formData.price
            productsObj.quantity=formData.quantity
            productsObj.description=formData.description
            productsObj.image="product_images/"+req.file?.filename
            productsObj.stock=formData.stock
            productsObj.save()
            .then((productData)=>{
            res.json({
                status:200,
                success:true,
                message:"Category Added",
                data:productData
            })
        })
            .catch((err)=>{
                res.json({
                    status:500,
                    success:false,
                    message:"Internal server error",
                    error:err
                })
            }) 
        }
        else{
            res.json({
                status:200,
                success:true,
                message:"Category already exist with same name",
                data:productData
            })
        }
    })
   
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })
}
}
get=(req,res)=>{
    let formData=req.body
    let limit=formData.limit
    let currentPage=formData.currentPage
    console.log(formData)
    delete formData.limit
    delete formData.currentPage
    console.log(formData)
    ProductsModel.find(formData)
    .limit(limit)
    .skip((currentPage-1)*limit)
    .then(async(result)=>{
        if(result.length>0){
            let total=await ProductsModel.countDocuments().exec()
        res.json({
            status:200,
            success:true,
            message:"data fetched",
            total:total,
            data:result
        })
    }
      else{
        res.json({
            status:404,
            success:false,
            message:"No data found",
            data:result
        })
      }
    })
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"internal server error",
            error:err
        })
    })
}
/*const get = async (req, res) => {
    try {
        let formData = req.body;
        console.log("Received formData:", formData);

        let limit = parseInt(formData.limit) || 10; // Ensure it's a number
        let currentPage = parseInt(formData.currentPage) || 1;

        delete formData.limit;
        delete formData.currentPage;

        console.log("Query after deletion:", formData);

        let result = await ProductsModel.find(formData)
            .limit(limit)
            .skip((currentPage - 1) * limit);

        if (result.length > 0) {
            let total = await ProductsModel.countDocuments(formData).exec();
            res.json({
                status: 200,
                success: true,
                message: "Data fetched",
                total: total,
                data: result
            });
        } else {
            res.json({
                status: 404,
                success: false,
                message: "No data found"
            });
        }
    } catch (error) {
        console.error("Error fetching data:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};*/

single=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        ProductsModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            res.json({
                status:200,
                success:true,
                data:ProductData
            })
        })
        .catch((err)=>{
            res.json({
                status:404,
                success:false,
                message:"Internal server error"
            })
        })
    }
}
deleteProduct=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        ProductsModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            if(!ProductData){
                res.json({
                    status:404,
                    success:false,
                    message:"data not found"
                })
            }
            else{
                ProductsModel.deleteOne({_id:formData._id})
                .then(()=>{
                    res.json({
                        status:200,
                        success:true,
                        
                        message:"Brand deleted"
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:404,
                        success:false,
                        message:"data not deleted"
                    })
                })
            }
        })
        .catch((err)=>{
            res.json({
            status:404,
            success:false,
            message:"internal server error"
            })
        
    })
}
}
deleteByParams=(req,res)=>{
    let formData=req.params
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        ProductsModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            if(!ProductData){
                res.json({
                    status:404,
                    success:false,
                    message:"data not found"
                })
            }
            else{
                ProductsModel.deleteOne({_id:formData._id})
                .then(()=>{
                    res.json({
                        status:200,
                        success:true,
                        
                        message:"Brand deleted"
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:404,
                        success:false,
                        message:"data not deleted"
                    })
                })
            }
        })
        .catch((err)=>{
            res.json({
            status:404,
            success:false,
            message:"internal server error"
            })
        
    })
}
}
update=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        ProductsModel.findOne({_id:formData._id})
        .then((BrandData)=>{
            if(!BrandData){
                res.json({
                    status:404,
                    success:false,
                    message:"data not found"
                })
            }
            else{
                if(!!formData.category){
                    BrandData.category=formData.category
                }
                if(req.file){
                    BrandData.image="product_images/"+req.file?.filename
                }
                BrandData.save()
                .then((BrandData)=>{
                    res.json({
                        status:200,
                        success:true,
                        message:"data is updated",
                        data:BrandData
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:404,
                        success:false,
                        message:"data is not updated"
                    })
                })
            }
        })
        .catch(()=>{
            res.json({
                status:404,
                success:false,
                message:"Internal server error"
            })
        })
    }
}
changeStatus=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        ProductsModel.findOne({_id:formData._id})
        .then((BrandData)=>{
            if(!BrandData){
                res.json({
                    status:404,
                    success:false,
                    message:"data not found"
                })
            }
            else{
                BrandData.status=!BrandData.status
                BrandData.save()
                .then((BrandData)=>{
                    res.json({
                        status:200,
                        success:true,
                        message:"status updated successfully",
                        data:BrandData
                    })
                })
                .catch(()=>{
                    
                            res.json({
                                status:404,
                                success:false,
                                message:"status is not updated"
                            })
                       
                    
                })
            }
        })
                .catch(()=>{
                    res.json({
                        status:404,
                        success:false,
                        message:"Internal server error"
                    })
                })
                    
            }
}

module.exports={add,get,single,deleteProduct,deleteByParams,update,changeStatus}