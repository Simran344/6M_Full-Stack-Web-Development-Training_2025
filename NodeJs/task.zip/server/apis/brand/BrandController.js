const BrandModel = require("./BrandModel")

add = (req, res) => {
    let formData = req.body
    let validation = ""
    if (!formData.brandName) {
        validation += "brandName is required"
    }
    if(!req.file){
        validation+="img is required to upload"
    }
    if (validation.trim()) {
        res.json({
            status: 422,
            success: false,
            messahe: "Validation error"
        })
    }
    else {
        BrandModel.findOne({ brandName: formData.brandName })
            .then(async (brandData) => {
                if (!brandData) {
                    let total = await BrandModel.countDocuments().exec()
                    let brandObj = new BrandModel()
                    brandObj.brandName = formData.brandName
                    brandObj.image="brand_images/"+req.file?.filename
                    brandObj.autoId = total + 1
                    brandObj.save()
                        .then((brandObj) => {
                            res.json({
                                status: 200,
                                success: true,
                                message: "data added",
                                data: brandObj
                            })
                        })
                        .catch(() => {
                            res.json({
                                status: 404,
                                success: false,
                                message: "data not added"
                            })
                        })
                }
                else {
                    res.json({
                        status: 200,
                        success: true,
                        message: "brand name already exists with same name"
                    })
                }
            })
            .catch((err) => {
                res.json({
                    status: 404,
                    success: false,
                    message: "Internal server error"
                })
            })
    }
}
get=(req, res)=>{
    let formData = req.body
    let limit = formData.limit
    let currentPage = formData.currentPage
    delete formData.limit
    delete formData.currentPage

    BrandModel.find(formData)
        .limit(limit)
        .skip((currentPage - 1) * limit)
        .then(async(brandData) => {
            if (brandData.length > 0) {
                let total = await BrandModel.countDocuments().exec()
                res.json({
                    status: 200,
                    success: true,
                    message: "data fetched",
                    total: total,
                    data: brandData
                })
            }
            else {
                res.json({
                    status: 404,
                    success: false,
                    message: "No data found"
                    
                })
            }
        })

    .catch ((err) => {
    res.json({
        status: 404,
        success: false,
        message: "Internal server error"
    })
})
}

single=(req,res)=>{
     let formData=req.body
        let validation=""
        if(!formData._id){
            validation+="_id is required"
        }
        if(!!validation.trim()){
              res.json({
                  status:422,
                  success:false,
                  message:"Validation error"
              })
        }
        else{
            BrandModel.findOne({_id:formData._id})
            .then((brandData)=>{
                res.json({
                    status:200,
                    success:true,
                    data:brandData
                })
            })
            .catch((err)=>{
                res.json({
                    status:404,
                    success:false,
                    message:"Internal server error"
                })
            })
        }
}
let update=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        BrandModel.findOne({_id:formData._id})
        .then((brandData)=>{
            if(!brandData){
                res.json({
                    status:404,
                    success:false,
                    message:"data not found"
                })
            }
            else{
                if(!!formData.category){
                    brandData.category=formData.category
                }
                if(req.file){
                    brandData.image="brand_images/"+req.file?.filename
                }
                brandData.save()
                .then((brandData)=>{
                    res.json({
                        status:200,
                        success:true,
                        message:"data is updated",
                        data:brandData
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:404,
                        success:false,
                        message:"data is not updated"
                    })
                })
            }
        })
        .catch(()=>{
            res.json({
                status:404,
                success:false,
                message:"Internal server error"
            })
        })
    }
}
let changeStatus=(req,res)=>{
    let formData=req.body
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
          res.json({
              status:422,
              success:false,
              message:"Validation error"
          })
    }
    else{
        BrandModel.findOne({_id:formData._id})
        .then((brandData)=>{
            if(!brandData){
                res.json({
                    status:404,
                    success:false,
                    message:"data not found"
                })
            }
            else{
                brandData.status=!brandData.status
                brandData.save()
                .then((brandData)=>{
                    res.json({
                        status:200,
                        success:true,
                        message:"status updated successfully",
                        data:brandData
                    })
                })
                .catch(()=>{
                    
                            res.json({
                                status:404,
                                success:false,
                                message:"status is not updated"
                            })
                       
                    
                })
            }
        })
                .catch(()=>{
                    res.json({
                        status:404,
                        success:false,
                        message:"Internal server error"
                    })
                })
                    
            }
}

module.exports = {add,get,single,update,changeStatus}