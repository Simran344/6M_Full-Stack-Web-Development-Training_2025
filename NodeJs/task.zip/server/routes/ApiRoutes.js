const multer=require("multer")
const CategoryController=require("../apis/category/CategoryController")
const ProductsController=require("../apis/products/ProductsController")
const BrandController=require("../apis/brand/BrandController")
const router=require("express").Router()

const Brandstorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './server/public/brand_images/')
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      cb(null, file.fieldname + '-' + uniqueSuffix + '-'+ file.originalname)
    }
  })
  
  const Brandupload = multer({storage: Brandstorage })
router.get("/brand/add",Brandupload.single("image"),BrandController.add)
router.get("/brand/get",BrandController.get)
router.get("/brand/single",BrandController.single)
router.get("/brand/update",Brandupload.single("image"),BrandController.update)
router.get("/brand/status",BrandController.changeStatus)

router.get("/category/ad",CategoryController.add)
router.get("/category/get",CategoryController.get)
router.get("/category/single",CategoryController.single)
router.get("/category/delete",CategoryController.deleteCategory)
router.delete("/category/deleteByPara/:_id",CategoryController.deleteByPara)
router.get("/category/update",CategoryController.updates)
router.get("/category/status",CategoryController.changeStat)

const Productstorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './server/public/product_images/')
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      cb(null, file.fieldname + '-' + uniqueSuffix + '-'+ file.originalname)
    }
  })
  
  const Productupload = multer({storage: Productstorage })
router.get("/products/add",Productupload.single("image"),ProductsController.add)
router.get("/products/ge",ProductsController.get)
router.get("/products/sing",ProductsController.single)
router.get("/products/delete",ProductsController.deleteProduct)
router.delete("/products/deleteByParams/:_id",ProductsController.deleteByParams)
router.get("/products/update",Productupload.single("image"),ProductsController.update)
router.get("/products/status",ProductsController.changeStatus)
router.get("/brand/add",BrandController.add)

module.exports=router