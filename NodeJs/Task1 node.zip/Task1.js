const express=require("express")

const app=express()

const PORT=5500;

app.listen(PORT,()=>{
    console.log("Port is listening",PORT)
})

app.get("/",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"My name is Simran"
    })
})

app.post("/first",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"GNDU Regional Campus,Jalandhar"
    })
})

app.get("/third",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"My hobby is learning new things.I enjoy exploring new concepts,gaining knowledge in different fields"
    })
})

app.post("/fourth",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"My course is MERN Stack"
    })
})

app.get("/sixth",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Technology used MongoDb,ReactJs,ExpressJs,NodeJs,Javascript"
    })
})