const mongoose=require("mongoose")

mongoose.connect("mongodb://localhost:27017/SkillHunt")

.then(()=>{
    console.log("database is connected")
})

.catch((error)=>{
    console.log("Error while connecting database",error)
})