const CategoryController=require("../apis/category/CategoryController")
const ProductsController=require("../apis/products/ProductsController")
const BrandController=require("../apis/brand/BrandController")
const router=require("express").Router()

router.get("/category/add",CategoryController.add)


router.get("/products/add",ProductsController.add)

router.get("/brand/add",BrandController.add)

module.exports=router