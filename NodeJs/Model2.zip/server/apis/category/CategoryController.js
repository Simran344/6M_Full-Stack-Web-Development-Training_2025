const CategoryModel=require("./CategoryModel")
add=(req,res)=>{
    let categoryObj=new CategoryModel
    categoryObj.categoryName=req.query.categoryName
    categoryObj.description=req.query.description
    categoryObj.save()
    .then((categoryData)=>{
        res.json({
            status:200,
            success:true,
            message:"Add api is working",
            data:categoryData
        })
    })
    
    .catch((err)=>{
        res.json({
        status:500,
        success:false,
        message:"Internal server error",
        error:err
    })
})
}



module.exports={add}