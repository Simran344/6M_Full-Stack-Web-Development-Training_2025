const mongoose=require("mongoose") 

let ProductsSchema=mongoose.Schema({
    category:{type:String,default:""},
    name:{type:String,default:""},
    brand:{type:String,default:""},
    price:{type:Number,default:""},
    quantity:{type:Number,default:0},
    description:{type:String,default:""},
    image:{type:String,default:""},
    stock:{type:Number,default:""},
    status:{type:Boolean,default:true},
    createdAt:{type:Date,default:Date.now()}
})
module.exports=mongoose.model("ProductsModel",ProductsSchema)