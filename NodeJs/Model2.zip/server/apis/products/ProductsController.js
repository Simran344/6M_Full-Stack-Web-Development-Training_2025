const ProductsModel=require("./ProductsModel")
add=(req,res)=>{
    let productsObj=new ProductsModel
    productsObj.category=req.query.category
    productsObj.name=req.query.name
    productsObj.brand=req.query.brand
    productsObj.price=req.query.price
    productsObj.quantity=req.query.quantity
    productsObj.description=req.query.description
    productsObj.image=req.query.image
    productsObj.stock=req.query.stock
    productsObj.save()
    .then((productData)=>{
    res.json({
        status:200,
        success:true,
        message:"Add product Api is working",
        data:productData
    })
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })
})
}

module.exports={add}