const BrandModel=require("./BrandModel")

add=(req,res)=>{
    let brandObj=new BrandModel
    brandObj.brandName=req.query.brandName
    brandObj.save()
    .then((brandData)=>{
        res.json({
            status:200,
            success:true,
            message:"Add brand api is working",
            data:brandData
        })
    })
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })
}
module.exports={add}