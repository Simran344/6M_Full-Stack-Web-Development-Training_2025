const ProductsModel=require("./ProductsModel")
add=(req,res)=>{
    let validation=""
    let formData=req.body
    if(!formData.category){
        validation+="Category is required"
        console.log(validation)
    }
    if(!formData.name){
        validation+="product name is required"
        console.log(validation)
    }
    if(!formData.brand){
        validation+="brand name is required"
        console.log(validation)
    }
    if(!formData.price){
        validation+="price is required"
        console.log(validation)
    }
    if(!formData.quantity){
        validation+="quantity is required"
        console.log(validation)
    }
    if(!formData.description){
        validation+="description is required"
        console.log(validation)
    }
    if(!formData.stock){
        validation+="stock  is required"
        console.log(validation)
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:"validation error"
        })
    }
    else{
    ProductsModel.findOne({category:formData.category})
    .then(async(productData)=>{
        if(!productData){
            let productsObj=new ProductsModel
            let total=await ProductsModel.countDocuments().exec()
            productsObj.autoId=total+1
            productsObj.category=formData.category
            productsObj.name=formData.name
            productsObj.brand=formData.brand
            productsObj.price=formData.price
            productsObj.quantity=formData.quantity
            productsObj.description=formData.description
            productsObj.image=formData.image
            productsObj.stock=formData.stock
            productsObj.save()
            .then((productData)=>{
            res.json({
                status:200,
                success:true,
                message:"Category Added",
                data:productData
            })
        })
            .catch((err)=>{
                res.json({
                    status:500,
                    success:false,
                    message:"Internal server error",
                    error:err
                })
            }) 
        }
        else{
            res.json({
                status:200,
                success:true,
                message:"Category already exist with same name",
                data:productData
            })
        }
    })
   
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })
}
}
get= (req,res)=>{
    let formData=req.body
    let limit=formData.limit
    let currentPage=formData.currentPage
    console.log(formData)
    delete formData.limit
    delete formData.currentPage
    console.log(formData)
    ProductsModel.find(formData)
    .limit(limit)
    .skip((currentPage-1)*limit)
    .then(async(result)=>{
        if(result.length>0){
            let total=await ProductsModel.countDocuments().exec()
        res.json({
            status:200,
            success:true,
            message:"data fetched",
            total:total,
            data:result
        })
    }
      else{
        res.json({
            status:404,
            success:false,
            message:"No data found",
            data:result
        })
      }
    })
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"internal server error",
            error:err
        })
    })
}
/*const get = async (req, res) => {
    try {
        let formData = req.body;
        console.log("Received formData:", formData);

        let limit = parseInt(formData.limit) || 10; // Ensure it's a number
        let currentPage = parseInt(formData.currentPage) || 1;

        delete formData.limit;
        delete formData.currentPage;

        console.log("Query after deletion:", formData);

        let result = await ProductsModel.find(formData)
            .limit(limit)
            .skip((currentPage - 1) * limit);

        if (result.length > 0) {
            let total = await ProductsModel.countDocuments(formData).exec();
            res.json({
                status: 200,
                success: true,
                message: "Data fetched",
                total: total,
                data: result
            });
        } else {
            res.json({
                status: 404,
                success: false,
                message: "No data found"
            });
        }
    } catch (error) {
        console.error("Error fetching data:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
};*/

module.exports={add,get}