const CategoryController=require("../apis/category/CategoryController")
const ProductsController=require("../apis/products/ProductsController")
const BrandController=require("../apis/brand/BrandController")
const router=require("express").Router()

router.get("/category/ad",CategoryController.add)
router.get("/category/get",CategoryController.get)

router.get("/products/add",ProductsController.add)
router.get("/products/ge",ProductsController.get)
router.get("/brand/add",BrandController.add)

module.exports=router